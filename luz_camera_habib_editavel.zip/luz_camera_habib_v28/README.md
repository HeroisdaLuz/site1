# Luz, Câmera e Habib - Site Editável

Este é o código-fonte completo do site "Luz, Câmera e Habib", pronto para edição independente.

## Estrutura do Projeto

```
luz_camera_habib_v28/
├── css/
│   └── styles.css       # Todos os estilos do site
├── fonts/
│   ├── TAN-NIMBUS.otf   # Fonte principal para títulos
│   └── Kenao.otf        # Fonte secundária para textos e botões
├── images/
│   └── infinity-symbol.png  # Símbolo do infinito para seção Metodologia
├── js/
│   └── main.js          # JavaScript para animações e interatividade
└── index.html           # Estrutura HTML principal do site
```

## Como Editar o Site

### Edição de Conteúdo

Para editar o conteúdo do site, abra o arquivo `index.html` em qualquer editor de código (como VS Code, Sublime Text, Notepad++, etc.) e modifique os textos conforme necessário.

### Edição de Estilos

Para modificar cores, tamanhos, espaçamentos e outros aspectos visuais, edite o arquivo `css/styles.css`.

### Edição de Comportamento

Para alterar animações e interatividade, edite o arquivo `js/main.js`.

## Observações Importantes

1. **Versão Web vs. Mobile**: A versão web está finalizada e aprovada. Quaisquer ajustes futuros devem ser focados apenas na versão mobile.

2. **Fontes**: As fontes TAN NIMBUS e Kenao estão incluídas na pasta `fonts/` e já estão configuradas no CSS.

3. **Responsividade**: O site já está configurado para ser responsivo, com ajustes específicos para tablets e celulares nas media queries ao final do arquivo CSS.

4. **Animações**: As animações de surgimento dos elementos estão implementadas tanto para desktop quanto para mobile.

## Pontos de Atenção para Versão Mobile

Se precisar fazer ajustes na versão mobile, foque nos seguintes pontos:

1. **Alinhamento de Textos**: Especialmente na seção "Personalização e Autonomia" com o ícone de dardo/alvo.

2. **Símbolos e Ícones**: Garanta que o símbolo do infinito na seção "Abordagem Multilíngue" e a estrela em "Contato" estejam corretos.

3. **Textos de Contato**: Verifique se o texto abaixo de "Fale Conosco" está idêntico à versão web.

4. **Botões**: Certifique-se que todos os botões mantenham a mesma formatação da versão web.

5. **Animações**: Confirme que as animações de surgimento dos elementos funcionam corretamente na versão mobile.

## Publicação

Para publicar o site, basta fazer upload de todos os arquivos e pastas para seu servidor web, mantendo a mesma estrutura de diretórios.
